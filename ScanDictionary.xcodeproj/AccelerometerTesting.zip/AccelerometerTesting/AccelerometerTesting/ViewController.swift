//
//  ViewController.swift
//  AccelerometerTesting
//
//  Created by Darius Howe on 3/21/19.
//  Copyright © 2019 Darius Howe. All rights reserved.
//

import UIKit

//Need to import core motion package to call accelerometer detector
import CoreMotion

class ViewController: UIViewController {

    //Create instance variable to be used by function
    //Motion manager is what the app uses to determine if activity is happening in any frame or over a certain time frame.
    var motionDetector = CMMotionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //True or false to determine if an action did or did not happen
    //Speculates then what steps to take next
    override func viewDidAppear(_ animated: Bool) {
        
        //Every 2 seconds the detector will update the console to know if motion is or is not happening
        motionDetector.accelerometerUpdateInterval=0.01
        
        //Pass two values into our Update protocol so that it has to make a decision based on these two inputs from the app
        motionDetector.startAccelerometerUpdates(to: OperationQueue.current!){ (data,error)in
            if let myMotion = data
                {
                    print(myMotion)
            }
        }
    }


}

